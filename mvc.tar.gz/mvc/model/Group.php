<?php

class Group {

    public $group;

    public function __construct($group)
    {

        $this->group = $group;

    }
}

?>